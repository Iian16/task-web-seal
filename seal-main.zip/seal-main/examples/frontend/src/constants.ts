// Copyright (c), Mysten Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

export const DEVNET_PACKAGE_ID = '0xTODO';
export const TESTNET_PACKAGE_ID =
  '0x4cb081457b1e098d566a277f605ba48410e26e66eaab5b3be4f6c560e9501800';
export const MAINNET_PACKAGE_ID = '0xTODO';
